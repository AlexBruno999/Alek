#include <stdlib.h>
#include <stdio.h>


 int main (){
  
  float valor_imovel, valor_prestacao, quantidade, anos;
  
  printf ("Digite o valor do imovel: \n");
  scanf("%f", &valor_imovel);
  printf ("Digite o valor da prestacao: \n");
  scanf("%f", &valor_prestacao);
  
  quantidade =  valor_imovel / valor_prestacao;
  anos = quantidade /12;
  
  printf ("A quantidade de meses ate quitar o imovel sera: %.1f \n", quantidade);
  printf ("A quantidade de anos ate quitar o imovel sera: %.1f \n", anos);
  
 
 system("pause");
 return 0;
 }
