#include <stdlib.h>
#include <stdio.h>  



  int main() {
  
   
   float anos, anos2, cigarros, preco, total;
   printf("Digite quantos anos a pessoa fuma: \n");
   scanf("%f", &anos);
   printf("Digite quantos cigarros a pessoa fuma por dia: \n");
   scanf("%f", &cigarros);
   printf("Digite o preco do cigarro: \n");
   scanf("%f", &preco);
   
   anos2 = anos * 365;
   total = anos2 * cigarros * preco;
   
   printf("O Fumante gastou:%f \n", total);
  
  
  
  
  
  
  
  
  
  
  system ("pause");
  return 0;
  
  }
  
