#include <stdlib.h>
#include <stdio.h>  


     int main(){
	    
	    float n1, n2, soma, multiplicacao, divisao;
	    
	    printf ("Digite um numero: \n");
	    scanf ("%f", &n1);
	    printf ("Digite um numero: \n");
	    scanf ("%f", &n2);
	    
	    soma = n1 + n2;
	    multiplicacao = n1 * n2;
	    divisao = n1 / n2;
	    
	    printf ("Soma: %f \n", soma);
        printf ("Multiplicacao: %f \n", multiplicacao);   	    
	    printf ("Divisao: %.2f \n", divisao);
	 
	 
	 
	 
	  system ("pause");
	  return 0;
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 }
