#include <stdlib.h>
#include <stdio.h>


  int main (){
  
       int n1, n2;
	   
	   printf ("Digite um numero \n");
	   scanf ("%i", &n1);
	   n2 = n1 - 1;
	   printf ("Numero antecessor: %i \n", n2);
	   
	   
	   
	   
	system ("pause");
	return 0;  
}
