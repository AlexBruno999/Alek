#include <stdlib.h>
#include <stdio.h>


  int main (){
 
   float abastecimento, gasolina, litros;
   printf("Digite o valor do quanto de gasolina voce deseja: \n");
   scanf("%f", &abastecimento);
   printf("Digite o atual valor da gasolina: \n");
   scanf("%f", &gasolina);
   litros = abastecimento / gasolina;
   
   printf("A Quantidade de litros e: %0.2fL \n", litros);


system("pause");
return 0;
}
