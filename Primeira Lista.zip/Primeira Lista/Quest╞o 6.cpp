#include <stdlib.h>
#include <stdio.h>

  int main (){

   float salario, aumento, total;
   printf ("Digite seu salario \n");
   scanf ("%f", &salario);
   
   aumento = (salario * 25) /100;
   total = salario + aumento;
   printf ("Seu novo salario e: %.2f \n", total);
   

 system("pause");
 return 0;

 }
