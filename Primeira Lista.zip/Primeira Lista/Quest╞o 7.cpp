#include <stdlib.h>
#include <stdio.h>


 int main (){

   float peso, engordar, emagrecer, res_engordar, res_emagrecer;
   printf ("Digite o seu peso atual: \n");
   scanf ("%f", &peso);
   
   engordar = (peso * 15) /100;
   emagrecer = (peso * 20) /100;
   
   res_engordar = peso + engordar;
   res_emagrecer = peso - emagrecer;
   
   printf ("Seu peso apos engordar: %.1f\n", res_engordar);
   printf ("Seu peso apos emagrecer: %.1f\n", res_emagrecer);


system ("pause");
return 0;
}
