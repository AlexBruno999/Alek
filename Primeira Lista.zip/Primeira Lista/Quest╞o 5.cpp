#include <stdlib.h>
#include <stdio.h>  



    int main(){
	
	float total, imposto, lucro, carro;
	printf ("Digite o valor do carro: \n");
	scanf("%f", &carro);
	imposto = (carro * 45) /100;
	lucro = (carro * 12) /100;
	total = imposto + lucro + carro;
	
	printf ("Total de impostos: %.2f \n", imposto);
    printf ("Total de lucro do vendedor: %.2f \n", lucro); 
	printf ("Custo total do carro: %.2f \n", total);
	
	
	system ("pause");
    return 0;


	}
	
	

























  






