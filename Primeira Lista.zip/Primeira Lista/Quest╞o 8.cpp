#include <stdlib.h>
#include <stdio.h>


  int main (){

  float salario, produto, valor;
  printf("Digite o seu salario: \n");
  scanf("%f", &salario);
  
  produto = (salario * 34) /100;
  printf ("O Valor mensal do produto e: %.2f\n", produto);


system("pause");
return 0;

}
